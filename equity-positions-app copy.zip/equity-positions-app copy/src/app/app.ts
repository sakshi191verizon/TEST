// src/app/app.component.ts
import { Component } from '@angular/core';
import { TransactionTab } from './components/transaction-tab';
import { PositionTab } from './components/position-tab';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [TransactionTab, PositionTab],
  templateUrl: './app.html',
  styleUrls: ['./app.scss']
})
export class App {
  activeTab: 'transactions' | 'positions' = 'transactions';
}
