import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PositionTab } from './position-tab';

describe('PositionTab', () => {
  let component: PositionTab;
  let fixture: ComponentFixture<PositionTab>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PositionTab]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PositionTab);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
