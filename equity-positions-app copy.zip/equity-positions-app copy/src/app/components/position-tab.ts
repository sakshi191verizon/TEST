import { Component, OnInit } from '@angular/core';
import { Equity } from '../services/equity';
import { Position } from '../model/position.model';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-position-tab',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './position-tab.html',
  styleUrls: ['./position-tab.scss'],
})
export class PositionTab implements OnInit {
  positions: Position[] = [];

  constructor(private equityService: Equity) {}

  ngOnInit(): void {
    this.equityService.getPositions().subscribe((data) => {
      this.positions = data;
    });
  }
}
