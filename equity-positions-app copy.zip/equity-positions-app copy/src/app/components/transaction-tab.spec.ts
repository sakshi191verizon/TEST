import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransactionTab } from './transaction-tab';

describe('TransactionTab', () => {
  let component: TransactionTab;
  let fixture: ComponentFixture<TransactionTab>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TransactionTab]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TransactionTab);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
