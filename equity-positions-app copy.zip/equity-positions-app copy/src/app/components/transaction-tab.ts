// src/app/components/transaction-tab.component.ts
import { Component } from '@angular/core';
import { Equity } from '../services/equity';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-transaction-tab',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './transaction-tab.html',
  styleUrls: ['./transaction-tab.scss'],
})
export class TransactionTab {
  transactions: any[] = [];
  transaction = {
    tradeId: '',
    version: '',
    securityCode: '',
    quantity: '',
    action: 'INSERT',
    direction: 'Buy',
  };

  constructor(private equityService: Equity) {
    this.loadTransactions();
  }

  loadTransactions() {
    this.equityService.getTransactions().subscribe((data) => {
      this.transactions = data;
    });
  }

  submitTransaction() {
    this.equityService.addTransaction(this.transaction).subscribe((data) => {
      this.transactions = data;
      this.resetForm();
    });
  }

  resetForm() {
    this.transaction = {
      tradeId: '',
      version: '',
      securityCode: '',
      quantity: '',
      action: 'INSERT',
      direction: 'Buy',
    };
  }
}
