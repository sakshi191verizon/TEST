export interface Position {
  securityCode: string;
  netQuantity: number;
}
