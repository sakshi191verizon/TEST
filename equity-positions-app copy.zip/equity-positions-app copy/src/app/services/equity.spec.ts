import { TestBed } from '@angular/core/testing';

import { Equity } from './equity';

describe('Equity', () => {
  let service: Equity;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Equity);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
