import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {Position} from '../model/position.model';

@Injectable({ providedIn: 'root' })
export class Equity {
  private baseUrl = 'http://localhost:8080/api';

  constructor(private http: HttpClient) {}

  getTransactions(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/list/transactions`);
  }

  addTransaction(tx: any): Observable<any[]> {
    return this.http.post<any[]>(`${this.baseUrl}/transaction`, tx);
  }

  getPositions(): Observable<Position[]> {
    return this.http.get<Position[]>(`${this.baseUrl}/positions`);
  }
}
