package com.example.trading_app.controller;

import com.example.trading_app.entity.Position;
import com.example.trading_app.entity.Transaction;
import com.example.trading_app.service.PositionService;
import com.example.trading_app.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class TradeController {

    @Autowired
    private PositionService positionService;

    @Autowired
    private TransactionService transactionService;

    @PostMapping("/transaction")
    public Transaction postTransaction(@RequestBody Transaction tx) {
        positionService.process(tx);
       // return ResponseEntity.ok("Transaction processed.");
        return tx;
    }

    @GetMapping("/positions")
    public List<Position> getPositions() {
        return positionService.getPositions();
    }

    @GetMapping("/list/transactions")
    public List<Transaction> getAllTransactions() {
        return transactionService.getAllTxns();
    }
}