package com.example.trading_app.entity;



import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class AppliedTrade {

    @Id
    private String tradeId;

    private int version;

    private String securityCode;

    private int quantity;

    private String action;

    private String direction; // BUY or SELL
}
