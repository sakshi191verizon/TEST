package com.example.trading_app.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    private String tradeId;
    private int version;
    private String securityCode;
    private int quantity;
    private String direction;
    private String action; // INSERT, UPDATE, CANCEL


}
