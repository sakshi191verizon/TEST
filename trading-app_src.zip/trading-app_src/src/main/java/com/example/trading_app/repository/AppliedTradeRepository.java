package com.example.trading_app.repository;

import com.example.trading_app.entity.AppliedTrade;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AppliedTradeRepository extends JpaRepository<AppliedTrade, String> {
}