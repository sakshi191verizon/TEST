package com.example.trading_app.repository;

import com.example.trading_app.entity.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    Optional<Transaction> findByTradeId(String tradeId);
    List<Transaction> findByTradeIdOrderByVersionAsc(String tradeId);
}
