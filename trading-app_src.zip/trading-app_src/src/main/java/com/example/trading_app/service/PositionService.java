package com.example.trading_app.service;




import com.example.trading_app.entity.AppliedTrade;
import com.example.trading_app.entity.Position;
import com.example.trading_app.entity.Transaction;
import com.example.trading_app.repository.AppliedTradeRepository;
import com.example.trading_app.repository.PositionRepository;
import com.example.trading_app.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class PositionService {

    @Autowired
    private TransactionRepository transactionRepo;

    @Autowired
    private PositionRepository positionRepo;

    @Autowired
    private AppliedTradeRepository appliedTradeRepo;


    private final Map<String, Transaction> appliedTrades = new ConcurrentHashMap<>();


    private final Map<String, Long> positions = new ConcurrentHashMap<>();


    @PostConstruct
    public void initAppliedTrades() {
        List<AppliedTrade> saved = appliedTradeRepo.findAll();
        for (AppliedTrade at : saved) {
            Transaction tx = new Transaction();
            tx.setTradeId(at.getTradeId());
            tx.setVersion(at.getVersion());
            tx.setSecurityCode(at.getSecurityCode());
            tx.setQuantity(at.getQuantity());
            tx.setAction(at.getAction());
            tx.setDirection(at.getDirection());
            appliedTrades.put(at.getTradeId(), tx);
        }


        List<Position> all = positionRepo.findAll();
        for (Position pos : all) {
            positions.put(pos.getSecurityCode(), pos.getNetQuantity());
        }
    }


    public synchronized void process(Transaction tx) {
        // Save this version to transaction history
        transactionRepo.save(tx);

        // Fetch all versions of this tradeId
        List<Transaction> versions = transactionRepo.findByTradeIdOrderByVersionAsc(tx.getTradeId());
        Transaction latest = versions.getLast();

        // Rollback previously applied version
        Transaction previous = appliedTrades.get(tx.getTradeId());
        if (previous != null) {
            rollback(previous);
        }

        // If latest version is CANCEL, don't apply anything
        if ("CANCEL".equalsIgnoreCase(latest.getAction())) {
            appliedTrades.remove(tx.getTradeId());
            appliedTradeRepo.deleteById(tx.getTradeId());
            return;
        }

        // Apply the latest version
        apply(latest);

        // Track applied in memory and DB
        appliedTrades.put(tx.getTradeId(), latest);
        appliedTradeRepo.save(new AppliedTrade(
                latest.getTradeId(),
                latest.getVersion(),
                latest.getSecurityCode(),
                latest.getQuantity(),
                latest.getAction(),
                latest.getDirection()
        ));
    }


    private void apply(Transaction tx) {
        boolean isBuy = tx.getDirection().equalsIgnoreCase("Buy");
        long diff = isBuy ? tx.getQuantity() : -tx.getQuantity();
        updatePosition(tx.getSecurityCode(), diff);
    }


    private void rollback(Transaction tx) {
        boolean isBuy = tx.getDirection().equalsIgnoreCase("Buy");
        long delta = isBuy? -tx.getQuantity() : tx.getQuantity();
        updatePosition(tx.getSecurityCode(), delta);
    }


    private void updatePosition(String securityCode, long delta) {
        long current = positions.getOrDefault(securityCode, 0L);
        long updated = current + delta;
        positions.put(securityCode, updated);
        positionRepo.save(new Position(securityCode, updated));
    }


    public List<Position> getPositions() {
        return new ArrayList<>(positionRepo.findAll());
    }
}
