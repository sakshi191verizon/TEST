package com.example.trading_app.service;

import com.example.trading_app.entity.Transaction;
import com.example.trading_app.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepository transactionRepo;

    public List<Transaction> getAllTxns() {
        return transactionRepo.findAll();
    }
}
